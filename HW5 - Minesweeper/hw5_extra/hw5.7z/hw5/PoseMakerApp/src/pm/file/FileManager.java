package pm.file;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.json.JsonWriterFactory;
import javax.json.stream.JsonGenerator;
import pm.data.DataManager;
import pm.data.Info;
import pm.gui.Workspace;
import saf.components.AppDataComponent;
import saf.components.AppFileComponent;

/**
 * This class serves as the file management component for this application,
 * providing all I/O services.
 *
 * @author Richard McKenna
 * @author ?
 * @version 1.0
 */
public class FileManager implements AppFileComponent {
    static final String JSON_TAG_WIDTH = "WIDTH";
    static final String JSON_TAG_HEIGHT = "HEIGHT";
    static final String JSON_TAG_CLASS ="CLASS";
    static final String JSON_TAG_PACKAGE = "PACKAGE";
    static final String JSON_TAG_X = "X";
    static final String JSON_TAG_Y = "Y";
    static final String JSON_TAG_ID = "ID";
    static final String JSON_TAG_VARIABLE = "VARIABLE";
    static final String JSON_TAG_METHOD = "METHOD";
    static final String JSON_TAG_PARENT = "PARENT";


    
    /**
     * This method is for saving user work, which in the case of this
     * application means the data that constitutes the page DOM.
     * 
     * @param data The data management component for this application.
     * 
     * @param filePath Path (including file name/extension) to where
     * to save the data to.
     * 
     * @throws IOException Thrown should there be an error writing 
     * out data to the file.
     */
    @Override
    public void saveData(AppDataComponent data, String filePath) throws IOException {
        
        StringWriter sw = new StringWriter();
        // THEN THE TREE
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        //Workspace work = (Workspace) 
        //Workspace  dataManager = (Workspace)data;
        DataManager dataManager = (DataManager)data;
        ArrayList<Rectangle> rect = dataManager.getTags();
        ArrayList<Info> labels = dataManager.getInfo();
        
        
        fillArray(arrayBuilder, rect, labels);
        JsonArray nodesArray = arrayBuilder.build();
        
        // THEN PUT IT ALL TOGETHER IN A JsonObject
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add("CLASSES", nodesArray)
                .build();

        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
        Map<String, Object> properties = new HashMap<>(1);
        properties.put(JsonGenerator.PRETTY_PRINTING, true);
        JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
        JsonWriter jsonWriter = writerFactory.createWriter(sw);
        jsonWriter.writeObject(dataManagerJSO);
        jsonWriter.close();

        // INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath);
        JsonWriter jsonFileWriter = Json.createWriter(os);
        jsonFileWriter.writeObject(dataManagerJSO);
        String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath);
        pw.write(prettyPrinted);
        pw.close();
    }
    private JsonObject makeTagJsonObject(Rectangle shapes, Info labels) {
	String tagName;

	JsonObject jso = Json.createObjectBuilder()
		.add(JSON_TAG_ID,shapes.getId())
		.add(JSON_TAG_X, shapes.getX())
		.add(JSON_TAG_Y, shapes.getY())
		.add(JSON_TAG_WIDTH, shapes.getWidth())
		.add(JSON_TAG_HEIGHT, shapes.getHeight())
                .add(JSON_TAG_CLASS, labels.getClassName())
                .add(JSON_TAG_PACKAGE, labels.getPackageNamel())
		.build();
	return jso;
    }   
    public void fillArray(JsonArrayBuilder arrayBuilder, ArrayList<Rectangle> shapes, ArrayList<Info> labels){
        //ToOO using text labels instead of info class FIX
        System.out.println(shapes.size()+ "lanels" +labels.size());
        for(int i = 0; i < shapes.size(); i++){ 
            for(int q = 0; q < labels.size(); q++){
                if(shapes.get(i).getId().equals(labels.get(q).getId())){
                    JsonObject tagObject = makeTagJsonObject(shapes.get(i), labels.get(q));
                    arrayBuilder.add(tagObject);
                }
            }
            
            
        }    
    }
    /**
     * This method loads data from a JSON formatted file into the data 
     * management component and then forces the updating of the workspace
     * such that the user may edit the data.
     * 
     * @param data Data management component where we'll load the file into.
     * 
     * @param filePath Path (including file name/extension) to where
     * to load the data from.
     * 
     * @throws IOException Thrown should there be an error reading
     * in data from the file.
     */
    @Override
    public void loadData(AppDataComponent data, String filePath) throws IOException {
        // CLEAR THE OLD DATA OUT
	DataManager dataManager = (DataManager)data;

        
        
	dataManager.reset();
        
        dataManager.getTags().clear();
        dataManager.setSaved(true);
	
	// LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(filePath);
	
	// LOAD THE TAG TREE
	JsonArray jsonTagTreeArray = json.getJsonArray("CLASSES");
	loadShapes(jsonTagTreeArray, dataManager);
        dataManager.setLoaded(true);
    }
    

    // HELPER METHOD FOR LOADING DATA FROM A JSON FORMAT
    private JsonObject loadJSONFile(String jsonFilePath) throws IOException {
	InputStream is = new FileInputStream(jsonFilePath);
	JsonReader jsonReader = Json.createReader(is);
	JsonObject json = jsonReader.readObject();
	jsonReader.close();
	is.close();
	return json;
    }
    
        private void loadShapes(JsonArray jsonTagsArray, DataManager dataManager) {
	ArrayList<Rectangle> rect = new ArrayList();
	// FIRST UPDATE THE ROOT
	
	// AND NOW JUST GO THROUGH THE REST OF THE ARRAY
	for (int i = 0; i < jsonTagsArray.size(); i++) {
            JsonObject tag = jsonTagsArray.getJsonObject(i);

                Rectangle s = new Rectangle(tag.getInt(JSON_TAG_X),tag.getInt(JSON_TAG_Y),tag.getInt(JSON_TAG_WIDTH),tag.getInt(JSON_TAG_HEIGHT));
                Text label = new Text(tag.getString(JSON_TAG_CLASS));
                label.setX(tag.getInt(JSON_TAG_X) + 10.0);
                label.setY(tag.getInt(JSON_TAG_Y) + 20.0);
                s.setId(tag.getString(JSON_TAG_ID));
                s.setFill(Color.WHITE);
                s.setStroke(Color.BLACK);
                s.setOnMouseDragged(e ->{
                    if(s.getId().equals(dataManager.getSelected())){
                        s.setX(e.getX());
                        s.setY(e.getY());
                        label.setX(e.getX() + 10);
                        label.setY(e.getY() + 20);
                    }
                });
                s.setOnMousePressed(e ->{
                    if(dataManager.move() == true){
                        dataManager.setSelected(s.getId());
                        dataManager.setIsSelected(true);
                        s.setStyle("-fx-effect: innershadow(gaussian, #000FFF, 5, 1.0, 0, 0);");
                    }
                    
                });
                
                rect.add(s);
                dataManager.addShape(s);
                dataManager.addLabels(label);
                dataManager.addinfo(tag.getString(JSON_TAG_CLASS),tag.getString(JSON_TAG_PACKAGE), tag.getString(JSON_TAG_ID));
            
            //Shape s = new Rectangle(tag.getInt(JSON_TAG_X),tag.getInt(JSON_TAG_Y),tag.getInt(JSON_TAG_WIDTH),tag.getInt(JSON_TAG_HEIGHT));
            //shapes.add(s);

	}
    }
    
    /**
     * This method exports the contents of the data manager to a 
     * Web page including the html page, needed directories, and
     * the CSS file.
     * 
     * @param data The data management component.
     * 
     * @param filePath Path (including file name/extension) to where
     * to export the page to.
     * 
     * @throws IOException Thrown should there be an error writing
     * out data to the file.
     */
    @Override
    public void exportData(AppDataComponent data, String filePath) throws IOException {

    }
    
    /**
     * This method is provided to satisfy the compiler, but it
     * is not used by this application.
     */
    @Override
    public void importData(AppDataComponent data, String filePath) throws IOException {
	// NOTE THAT THE Web Page Maker APPLICATION MAKES
	// NO USE OF THIS METHOD SINCE IT NEVER IMPORTS
	// EXPORTED WEB PAGES
    }
}
