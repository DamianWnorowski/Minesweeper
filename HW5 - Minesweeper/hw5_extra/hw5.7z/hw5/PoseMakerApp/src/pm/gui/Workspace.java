package pm.gui;

import java.io.IOException;
import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.*;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javax.swing.JSplitPane;
import pm.controller.PaneController;
import pm.data.DataManager;
import pm.data.DraggableClass;
import saf.ui.AppGUI;
import saf.AppTemplate;
import saf.components.AppWorkspaceComponent;

/**
 * This class serves as the workspace component for this application, providing
 * the user interface controls for editing work.
 *
 * @author Richard McKenna
 * @author ?
 * @version 1.0
 */
public class Workspace extends AppWorkspaceComponent {

    // HERE'S THE APP
    AppTemplate app;

    // IT KNOWS THE GUI IT IS PLACED INSIDE
    AppGUI gui;
    FlowPane fileToolBar;
    Button but;
    Button photo;
    Button code;
    Button select;
    Button resize;
    Button addClass;
    Button addInterface;
    Button remove;
    Button undo;
    Button redo;
    Button zoomIn;
    Button zoomOut;
    SplitPane splitPane;
    Pane classPane;
    Pane infoPane;
    Pane textFieldPane;
    Pane tableViewPane;
    BorderPane topInfoPane;
    VBox vTable;
    HBox hBox;
    VBox vBox;
    VBox vText;
    BorderPane borderPane;
    BorderPane infoBorder;
    Text className;
    Pane infoRight;
    TextField classText;
    TextField packText;
    TextField parentText;
    TableView methods;
    TableView variables;
    TableColumn variableName;
    TableColumn variableType;
    TableColumn variableStatic;
    TableColumn variableAccess;
    TableColumn methodName;
    TableColumn methodType;
    TableColumn methodStatic;
    TableColumn methodAccess;
    VBox infoBotBox;
    ScrollPane scrollPane;
    DataManager dataManager;
    PaneController controller;
    int id;
    Boolean isSelected;
    String selectedClass;
    
   
    
    

    /**
     * Constructor for initializing the workspace, note that this constructor
     * will fully setup the workspace user interface for use.
     *
     * @param initApp The application this workspace is part of.
     *
     * @throws IOException Thrown should there be an error loading application
     * data for setting up the user interface.
     */
    public Workspace(AppTemplate initApp) throws IOException {
	// KEEP THIS FOR LATER
	app = initApp;
        dataManager = (DataManager) app.getDataComponent(); 
        id = 0;
        isSelected = false;
        
	// KEEP THE GUI FOR LATER
	gui = app.getGUI();
        photo = new Button();
        workspace = new Pane();
        fileToolBar = new FlowPane(); 
        splitPane = new SplitPane();
        classPane = new Pane();
        infoPane = new Pane();
        borderPane = new BorderPane();
        className = new Text("Class Name");
        vBox = new VBox(60);
        vText = new VBox(60);
        infoBorder = new BorderPane();
        infoRight = new Pane();
        classText = new TextField();
        packText = new TextField();
        parentText = new TextField();
        textFieldPane = new Pane();
        methods = new TableView();   
        variables = new TableView();
        infoBotBox = new VBox();
        scrollPane = new ScrollPane();
        
        tableViewPane = new Pane();
        vTable = new VBox();
        topInfoPane = new BorderPane();

        
        variableName = new TableColumn("Name");
        variableName.setCellValueFactory(new PropertyValueFactory("title"));
        variableType = new TableColumn("Type");
        variableType.setCellValueFactory(new PropertyValueFactory("type"));
        variableStatic = new TableColumn("Static");
        variableStatic.setCellValueFactory(new PropertyValueFactory("static"));
        variableAccess = new TableColumn("Access");
        variableAccess.setCellValueFactory(new PropertyValueFactory("access"));
        
        methodName = new TableColumn("Name");
        methodName.setCellValueFactory(new PropertyValueFactory("title"));
        methodType = new TableColumn("Type");
        methodType.setCellValueFactory(new PropertyValueFactory("type"));
        methodStatic = new TableColumn("Static");
        methodStatic.setCellValueFactory(new PropertyValueFactory("static"));
        methodAccess = new TableColumn("Access");
        methodAccess.setCellValueFactory(new PropertyValueFactory("access"));
        
        scrollPane.setContent(variables);
        
        variableName.setMinWidth(100);
        variableType.setMinWidth(100);
        variableStatic.setMinWidth(100);
        variableAccess.setMinWidth(100);
        
        
        variables.setStyle("-fx-scroll-bar:vertical;-fx-scroll-bar:horizontal;");
        variables.getColumns().setAll(variableName, variableType, variableStatic, variableAccess);
        variables.setMaxWidth(360);
        variables.setMaxHeight(200);
        
        methods.getColumns().setAll(methodName, methodType, methodStatic,methodAccess);
        methods.setMaxSize(360, 200);
        
        
        tableViewPane.getChildren().add(variables);

        
        classText.setPrefSize(150, 30);
        packText.setPrefSize(100, 30);
        parentText.setPrefSize(100, 30);

        photo = gui.addButton(but, "photo");
        code = gui.addButton(but, "Code");
        select = gui.addButton(but, "Select");
        resize = gui.addButton(but, "Resize");
        addClass = gui.addButton(but, "AddClass");
        addInterface = gui.addButton(but, "AddInterface");
        remove = gui.addButton(but, "delete");
        undo = gui.addButton(but, "Undo");
        redo = gui.addButton(but, "Redo");
        zoomIn = gui.addButton(but, "Zoomin");
        zoomOut = gui.addButton(but, "Zoomout");
        classPane.setStyle("-fx-background-color:lightgray;");
        //infoPane.setStyle("-fx-background-color:gray;");
        //infoBorder.setStyle("-fx-background-color:teal;");
        vText.setStyle("-fx-padding:30,20,0,20;");
        
        Label classLabel = new Label("Class Name:");
        classLabel.setFont(new Font(30));
        Label packLabel = new Label("Package:");
        packLabel.setFont(new Font(20));
        Label parentLabel = new Label("Parent:");
        parentLabel.setFont(new Font(20));
        Label varLabel = new Label("Variables");
        varLabel.setFont(new Font(20));
        Label methodLabel = new Label("Methods");
        methodLabel.setFont(new Font(20));
        methodLabel.setPadding(new Insets(20,0,0,0));
        
        vText.getChildren().addAll(classText, packText, parentText);
        vBox.getChildren().addAll(classLabel, packLabel, parentLabel, varLabel);
        vBox.setPadding(new Insets(20,0,0,20));
        
        infoBotBox.getChildren().addAll(tableViewPane, methodLabel, methods);
        infoBotBox.setPadding(new Insets(0,0,0,20));
        
        
        infoPane.getChildren().add(vBox);
 
        topInfoPane.setLeft(infoPane);
        topInfoPane.setRight(textFieldPane);
        textFieldPane.getChildren().add(vText);
        
        infoBorder.setTop(topInfoPane);
        infoBorder.setLeft(infoBotBox);
        //infoBorder.setLeft(infoPane);
        //infoBorder.setRight(textFieldPane);
        classPane.setMinSize(1050, 1000);
        classPane.setMaxSize(1050, 1000);
        //infoPane.setMinSize(1000, 500);
        splitPane.getItems().addAll(classPane, infoBorder);
        borderPane.setLeft(classPane);
        borderPane.setRight(infoBorder);
        workspace.getChildren().add(splitPane);
        
        
        gui.addRadio();
        setupHandlers();

    }
    
    public void setupHandlers(){
        classText.setOnKeyReleased(e ->{
            if(dataManager.isIsSelected() == true){
                dataManager.addinfo(classText.getText(), packText.getText(), dataManager.getSelected());
                
                for(int i = 0; i < dataManager.getInfo().size(); i++){
                    
                    for(int q = 0; q < dataManager.getLabels().size(); q++){
                        if (dataManager.getLabels().get(q).getId().equals(dataManager.getSelected())) {
                        
                        dataManager.getLabels().get(q).setText(classText.getText());
                        }
                    }
                    
                }
                
                
            }
        });
        packText.setOnKeyReleased(e ->{
            if(dataManager.isIsSelected() == true){
                dataManager.addinfo(classText.getText(), packText.getText(), dataManager.getSelected());
            }
        });
        
        controller = new PaneController(app);
        
        photo.setOnAction(e ->{
            
        });
        code.setOnAction(e ->{
            
        });
        select.setOnAction(e ->{
            addClass.setDisable(false);
            select.setDisable(true);
            dataManager.setMove(true);
        });
        resize.setOnAction(e ->{
            
        });
        addClass.setOnAction(e ->{
            select.setDisable(false);
            dataManager.setMove(false);
            //addClass.setDisable(true);
            
            id++;
                Text label = new Text("");
                
                Rectangle rect = new Rectangle();
                label.setX(250+10);
                label.setY(250+20);
                label.setId("id:" + id);
                rect.setX(250);
                rect.setY(250);
                rect.setHeight(250);
                rect.setWidth(150);
                rect.setFill(Color.WHITE);
                rect.setStroke(Color.BLACK);
                rect.setId("id:"+id);
                rect.setOnMousePressed(f ->{
                    classText.setText("");
                    packText.setText("");
                    dataManager.setSelected(rect.getId());
                    dataManager.setIsSelected(true);
                    //selectedClass = rect.getId();
                    //isSelected = true;
                    rect.setStyle("-fx-effect: innershadow(gaussian, #000FFF, 5, 1.0, 0, 0);");  
                    reloadWorkspace();
                });
                rect.setOnMouseDragged(g ->{
                    if(select.isDisable()== true){
                        label.setX((g.getX()-(rect.getWidth()/2))+10);
                        label.setY((g.getY()-(rect.getHeight()/2))+20);
                        rect.setX(g.getX()-(rect.getWidth()/2));
                        rect.setY(g.getY()-(rect.getHeight()/2));       
                    }
                });
                dataManager.addShape(rect);
                dataManager.addLabels(label);
                classPane.getChildren().add(rect);
                classPane.getChildren().add(label);
                addClass.setDisable(false);
                System.out.println(dataManager.getTags());
                
                
            
            
            
            

        });
        addInterface.setOnAction(e ->{
            
        });
        remove.setOnAction(e ->{
            
        });
        undo.setOnAction(e ->{
            
        });
        redo.setOnAction(e ->{
            
        });
        zoomIn.setOnAction(e ->{
            
        });
        zoomOut .setOnAction(e ->{
            
        });
        
        classPane.setOnMousePressed(e ->{
            if(addClass.isDisable() == true){
                id++;
                Text label = new Text("");
                
                Rectangle rect = new Rectangle();
                label.setX(e.getX()+10);
                label.setY(e.getY()+20);
                label.setId("id:" + id);
                rect.setX(e.getX());
                rect.setY(e.getY());
                rect.setHeight(250);
                rect.setWidth(150);
                rect.setFill(Color.WHITE);
                rect.setStroke(Color.BLACK);
                rect.setId("id:"+id);
                rect.setOnMousePressed(f ->{
                    classText.setText("");
                    packText.setText("");
                    dataManager.setSelected(rect.getId());
                    dataManager.setIsSelected(true);
                    rect.setStyle("-fx-effect: innershadow(gaussian, #000FFF, 5, 1.0, 0, 0);");
                    System.out.println(rect.getId());       
                    reloadWorkspace();
                });
                rect.setOnMouseDragged(g ->{
                    if(select.isDisable()== true){
                        label.setX(g.getX()+10);
                        label.setY(g.getY()+20);
                        rect.setX(g.getX());
                        rect.setY(g.getY());
                    }
                });
                dataManager.addShape(rect);
                dataManager.addLabels(label);
                classPane.getChildren().add(rect);
                classPane.getChildren().add(label);
                addClass.setDisable(false);
            }
            reloadWorkspace();
        }); 
    }
    
    public void drawClass(Rectangle rect){
        
    }
    public void setSelected(String selID){
        selectedClass = selID;
    }
    
    /**
     * This function specifies the CSS style classes for all the UI components
     * known at the time the workspace is initially constructed. Note that the
     * tag editor controls are added and removed dynamicaly as the application
     * runs so they will have their style setup separately.
     */
    @Override
    public void initStyle() {
	classPane.getChildren().clear();
    }
    
    public void clearPane(){
        classPane.getChildren().clear();
    }

    /**
     * This function reloads all the controls for editing tag attributes into
     * the workspace.
     */
    @Override
    public void reloadWorkspace() {
        classPane.getChildren().clear();
        classPane.getChildren().addAll(dataManager.getTags());
        classPane.getChildren().addAll(dataManager.getLabels());
        
        for (Rectangle shape : dataManager.getTags()) {
            if(dataManager.getLoaded() == true){       
                //classPane.getChildren().clear();
                //System.out.println("ERROR" + dataManager.getTags());
                //classPane.getChildren().addAll(dataManager.getTags());
                //classPane.getChildren().addAll(dataManager.getLabels());
                
            }
            
            if (dataManager.isIsSelected() == true) {
                //todo for selected item
                if (shape.getId().equals(dataManager.getSelected())) {

                    for (int i = 0; i < dataManager.getInfo().size(); i++) {
                        if (dataManager.getInfo().get(i).getId().equals(dataManager.getSelected())) {
                            classText.setText(dataManager.getInfo().get(i).getClassName());
                            packText.setText(dataManager.getInfo().get(i).getPackageNamel());
                            //dataManager.getLabels().get(i).setText(dataManager.getInfo().get(i).getClassName());
                        }
                    }
                } else {
                    shape.setStyle("");
                }
            }
                
        }
    }
}
