package pm.data;

import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;
import pm.gui.Workspace;
import saf.components.AppDataComponent;
import saf.AppTemplate;

/**
 * This class serves as the data management component for this application.
 *
 * @author Richard McKenna
 * @author ?
 * @version 1.0
 */
public class DataManager implements AppDataComponent {
    // THIS IS A SHARED REFERENCE TO THE APPLICATION
    AppTemplate app;
    String selected;
    ArrayList<Rectangle> tags;
    ArrayList<Info> rectInfo;
    ArrayList labels;
    ArrayList temp;
    String color;
    boolean saved;
    boolean move;
    Info info;
    boolean inInfo;
    boolean justLoaded;
    boolean isSelected;

    /**
     * THis constructor creates the data manager and sets up the
     *
     *
     * @param initApp The application within which this data manager is serving.
     */
    public DataManager(AppTemplate initApp) throws Exception {
	// KEEP THE APP FOR LATER
	app = initApp;
        tags = new ArrayList();   
        rectInfo = new ArrayList();
        labels = new ArrayList();
        inInfo = false;
        justLoaded = false;   
        isSelected = false;
        
    }
    public void setLoaded(Boolean bol){
        justLoaded = bol;
    }
    public Boolean getLoaded(){
        return justLoaded;
    }
    public void setMove(Boolean bol){
        move = bol;
    }
    public Boolean move(){
        return move;
    }
    
    public void addinfo(String className, String packageName, String idName){
        inInfo = false;
        info = new Info(idName, className, packageName);
        for(int i = 0; i < rectInfo.size(); i ++){
            if(rectInfo.get(i).id.equals(idName)){
                inInfo = true;
                rectInfo.get(i).setClassName(className);
                rectInfo.get(i).setPackageNamel(packageName);
            }
        }
        if(inInfo == false){
            rectInfo.add(info);
        }
        
        System.out.println(rectInfo);    
    }

    public void addShape(Rectangle shape){
        tags.add(shape);
    }
    public ArrayList<Rectangle> getTags() {
	return tags;
    }
    public ArrayList<Info> getInfo(){
        return rectInfo;
    }
    public void setBgColor(String bgColor){
        color = bgColor;
    }
    public boolean saved(){
        return saved;
    }
    public void setSaved(boolean save){
        saved = save;
    }
    public ArrayList<Text> getLabels() {
        return labels;
    }

    public void addLabels(Text label) {
        labels.add(label);
    }

    public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }

    public boolean isIsSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
    

    /**
     * This function clears out the HTML tree and reloads it with the minimal
     * tags, like html, head, and body such that the user can begin editing a
     * page.
     */
    @Override
    public void reset() {
        tags.clear();
        rectInfo.clear();
        labels.clear();
    }
}
