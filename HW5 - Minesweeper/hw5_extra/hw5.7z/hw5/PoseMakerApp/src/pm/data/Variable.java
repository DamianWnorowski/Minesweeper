/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pm.data;

/**
 *
 * @author Damian
 */
public class Variable {
    String name;
    String access;
    String type;
    Boolean isStatic;

    public Variable(String name, String access, String type, Boolean isStatic) {
        this.name = name;
        this.access = access;
        this.type = type;
        this.isStatic = isStatic;
    }

    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getIsStatic() {
        return isStatic;
    }

    public void setIsStatic(Boolean isStatic) {
        this.isStatic = isStatic;
    }

    @Override
    public String toString() {
        return "Variable{" + "name=" + name + ", access=" + access + ", type=" + type + ", isStatic=" + isStatic + '}';
    }
    
    
}
