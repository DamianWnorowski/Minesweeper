/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pm.data;

import java.util.ArrayList;

/**
 *
 * @author Damian
 */
public class Info {
    String id, className, packageNamel;
    ArrayList<Variable> variable = new ArrayList();
    ArrayList<Method> method = new ArrayList();

    public Info(String id, String className, String packageNamel) {
        this.id = id;
        this.className = className;
        this.packageNamel = packageNamel;
    }
    
    public void addVar(Variable var){
        variable.add(var);
    }
    public void addMeth(Method meth){
        method.add(meth);
    }
    
    public ArrayList<Method> newMeth(){
        return method;
    }
    public ArrayList<Variable> newVar(){
        return variable;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getPackageNamel() {
        return packageNamel;
    }

    public void setPackageNamel(String packageNamel) {
        this.packageNamel = packageNamel;
    }

    
    
    
    @Override
    public String toString() {
        return "Info{" + "id= " + id + ", className= " + className + ", packageNamel= " + packageNamel + '}';
    }
    
    
}
