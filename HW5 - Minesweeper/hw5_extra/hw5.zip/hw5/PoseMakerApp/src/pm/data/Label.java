/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pm.data;

import javafx.scene.text.Text;

/**
 *
 * @author Damian
 */
public class Label {
    String id;
    Text label;
    
    public void Label(Text text, String idClass){
        id = idClass;
        label = text;
        
    }
    

    
}
