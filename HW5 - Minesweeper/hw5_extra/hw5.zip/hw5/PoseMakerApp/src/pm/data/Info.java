/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pm.data;

/**
 *
 * @author Damian
 */
public class Info {
    String id, className, packageNamel;

    public Info(String id, String className, String packageNamel) {
        this.id = id;
        this.className = className;
        this.packageNamel = packageNamel;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getPackageNamel() {
        return packageNamel;
    }

    public void setPackageNamel(String packageNamel) {
        this.packageNamel = packageNamel;
    }

    
    
    
    @Override
    public String toString() {
        return "Info{" + "id= " + id + ", className= " + className + ", packageNamel= " + packageNamel + '}';
    }
    
    
}
