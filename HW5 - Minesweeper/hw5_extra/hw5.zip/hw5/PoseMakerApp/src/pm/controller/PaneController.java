/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pm.controller;

import pm.data.DataManager;
import pm.gui.Workspace;
import saf.AppTemplate;

/**
 *
 * @author Damian
 */
public class PaneController {
    AppTemplate app;
    
    public PaneController(AppTemplate initApp){
        app = initApp;
    }
    
    
    public void mousePressed(int x, int y){
        Workspace workspace = (Workspace)app.getWorkspaceComponent();      
        DataManager dataManager = (DataManager)app.getDataComponent();
	workspace.reloadWorkspace();
    }
    
    
}
